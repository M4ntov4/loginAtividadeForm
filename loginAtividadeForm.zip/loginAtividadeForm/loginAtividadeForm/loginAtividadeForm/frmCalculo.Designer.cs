﻿
namespace loginAtividadeForm
{
    partial class frmCalculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIMC = new System.Windows.Forms.Label();
            this.txtAltura = new System.Windows.Forms.Label();
            this.txtPeso = new System.Windows.Forms.Label();
            this.tbAltura = new System.Windows.Forms.TextBox();
            this.tbPeso = new System.Windows.Forms.TextBox();
            this.btCalcular = new System.Windows.Forms.Button();
            this.txtValorImc = new System.Windows.Forms.Label();
            this.txtResult = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtIMC
            // 
            this.txtIMC.AutoSize = true;
            this.txtIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIMC.Location = new System.Drawing.Point(34, 50);
            this.txtIMC.Name = "txtIMC";
            this.txtIMC.Size = new System.Drawing.Size(244, 42);
            this.txtIMC.TabIndex = 0;
            this.txtIMC.Text = "Calcular IMC";
            this.txtIMC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtAltura
            // 
            this.txtAltura.AutoSize = true;
            this.txtAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAltura.Location = new System.Drawing.Point(352, 76);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(100, 31);
            this.txtAltura.TabIndex = 1;
            this.txtAltura.Text = "Altura:";
            this.txtAltura.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtPeso
            // 
            this.txtPeso.AutoSize = true;
            this.txtPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPeso.Location = new System.Drawing.Point(358, 181);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(89, 31);
            this.txtPeso.TabIndex = 2;
            this.txtPeso.Text = "Peso:";
            this.txtPeso.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tbAltura
            // 
            this.tbAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAltura.Location = new System.Drawing.Point(304, 123);
            this.tbAltura.Name = "tbAltura";
            this.tbAltura.Size = new System.Drawing.Size(197, 38);
            this.tbAltura.TabIndex = 3;
            // 
            // tbPeso
            // 
            this.tbPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPeso.Location = new System.Drawing.Point(304, 229);
            this.tbPeso.Name = "tbPeso";
            this.tbPeso.Size = new System.Drawing.Size(197, 38);
            this.tbPeso.TabIndex = 4;
            // 
            // btCalcular
            // 
            this.btCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCalcular.Location = new System.Drawing.Point(321, 292);
            this.btCalcular.Name = "btCalcular";
            this.btCalcular.Size = new System.Drawing.Size(166, 43);
            this.btCalcular.TabIndex = 5;
            this.btCalcular.Text = "Calcular";
            this.btCalcular.UseVisualStyleBackColor = true;
            this.btCalcular.Click += new System.EventHandler(this.btCalcular_Click);
            // 
            // txtValorImc
            // 
            this.txtValorImc.AutoSize = true;
            this.txtValorImc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorImc.Location = new System.Drawing.Point(85, 178);
            this.txtValorImc.Name = "txtValorImc";
            this.txtValorImc.Size = new System.Drawing.Size(146, 31);
            this.txtValorImc.TabIndex = 6;
            this.txtValorImc.Text = "Resultado";
            this.txtValorImc.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtResult
            // 
            this.txtResult.AutoSize = true;
            this.txtResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResult.Location = new System.Drawing.Point(35, 121);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(151, 31);
            this.txtResult.TabIndex = 7;
            this.txtResult.Text = "Seu imc é:";
            this.txtResult.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtStatus
            // 
            this.txtStatus.AutoSize = true;
            this.txtStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.Location = new System.Drawing.Point(88, 236);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(98, 31);
            this.txtStatus.TabIndex = 8;
            this.txtStatus.Text = "Status";
            this.txtStatus.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // frmCalculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 361);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtValorImc);
            this.Controls.Add(this.btCalcular);
            this.Controls.Add(this.tbPeso);
            this.Controls.Add(this.tbAltura);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.txtAltura);
            this.Controls.Add(this.txtIMC);
            this.Name = "frmCalculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmCalculo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtIMC;
        private System.Windows.Forms.Label txtAltura;
        private System.Windows.Forms.Label txtPeso;
        private System.Windows.Forms.TextBox tbAltura;
        private System.Windows.Forms.TextBox tbPeso;
        private System.Windows.Forms.Button btCalcular;
        private System.Windows.Forms.Label txtValorImc;
        private System.Windows.Forms.Label txtResult;
        private System.Windows.Forms.Label txtStatus;
    }
}