﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;


namespace loginAtividadeForm
{
    public partial class frmEmail : Form
    {
        public frmEmail()
        {
            InitializeComponent();
        }

        private void btEnviar_Click(object sender, EventArgs e)
        {

            try
            {
                var smtpClient = new SmtpClient("smtp.gmail.com", 587);
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new System.Net.NetworkCredential("joaovdelaia@gmail.com", "vxvyjazaxmpoxgoa");
                smtpClient.EnableSsl = true;


                var mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(tbRemetente.Text); // endereço do remetente
                mailMessage.To.Add(tbDestinatario.Text); // endereço do destinatário
                mailMessage.Subject = tbAssunto.Text; // assunto do e-mail
                mailMessage.Body = tbConteudo.Text; // corpo do e-mail

                // Envio do e-mail
                smtpClient.Send(mailMessage);

                MessageBox.Show("E-mail enviado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao enviar e-mail: " + ex.Message);
            }

        }
    }
}
