﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loginAtividadeForm
{
    public partial class frmCalculo : Form
    {
        public frmCalculo()
        {
            InitializeComponent();
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            double peso = double.Parse(tbPeso.Text);
            double altura = double.Parse(tbAltura.Text);
            double imc = 0;

            if (peso < 0 && altura < 0 || peso < 500 && altura < 2.9)
            {
                //calcula imc
                imc = peso / (altura * altura);

                string valorFormatado = imc.ToString("F1");
                txtValorImc.Text = valorFormatado;

                imc = double.Parse(valorFormatado);

                if (imc < 18.5)
                {
                    txtStatus.Text = "Abaixo do peso normal";
                }
                else
                {
                    if (imc >= 18.5 && imc <= 24.9)
                    {
                        txtStatus.Text = "Peso normal";
                    }
                    else
                    {
                        if (imc >= 25 && imc <= 29.9)
                        {
                            txtStatus.Text = "Excesso de peso";
                        }
                        else
                        {
                            if (imc >= 30 && imc <= 34.9)
                            {
                                txtStatus.Text = "Obesidade Grau I";
                            }
                            else
                            {
                                if (imc >= 35 && imc <= 39.9)
                                {
                                    txtStatus.Text = "Obesidade Grau II";
                                }
                                else
                                {
                                    if (imc > 40)
                                    {
                                        txtStatus.Text = "Obesidade Grau III";
                                    }
                                    else
                                    {
                                        txtStatus.Text = "Valor invalido";
                                    }
                                }
                            }
                        }
                    }
                }



                

            }
            else
            {
                MessageBox.Show("Erro: valores invalidos");
            }


        }
    }
}
