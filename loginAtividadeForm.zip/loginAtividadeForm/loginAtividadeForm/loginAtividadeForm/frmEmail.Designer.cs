﻿
namespace loginAtividadeForm
{
    partial class frmEmail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEmailRemetente = new System.Windows.Forms.Label();
            this.tbRemetente = new System.Windows.Forms.TextBox();
            this.tbDestinatario = new System.Windows.Forms.TextBox();
            this.txtDestinatario = new System.Windows.Forms.Label();
            this.txtAssunto = new System.Windows.Forms.Label();
            this.tbAssunto = new System.Windows.Forms.TextBox();
            this.tbConteudo = new System.Windows.Forms.TextBox();
            this.txtCorpoEmail = new System.Windows.Forms.Label();
            this.btEnviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtEmailRemetente
            // 
            this.txtEmailRemetente.AutoSize = true;
            this.txtEmailRemetente.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailRemetente.Location = new System.Drawing.Point(14, 14);
            this.txtEmailRemetente.Name = "txtEmailRemetente";
            this.txtEmailRemetente.Size = new System.Drawing.Size(154, 24);
            this.txtEmailRemetente.TabIndex = 0;
            this.txtEmailRemetente.Text = "Email Remetente";
            // 
            // tbRemetente
            // 
            this.tbRemetente.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRemetente.Location = new System.Drawing.Point(174, 11);
            this.tbRemetente.Name = "tbRemetente";
            this.tbRemetente.Size = new System.Drawing.Size(291, 30);
            this.tbRemetente.TabIndex = 1;
            // 
            // tbDestinatario
            // 
            this.tbDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDestinatario.Location = new System.Drawing.Point(174, 47);
            this.tbDestinatario.Name = "tbDestinatario";
            this.tbDestinatario.Size = new System.Drawing.Size(291, 30);
            this.tbDestinatario.TabIndex = 3;
            // 
            // txtDestinatario
            // 
            this.txtDestinatario.AutoSize = true;
            this.txtDestinatario.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDestinatario.Location = new System.Drawing.Point(14, 50);
            this.txtDestinatario.Name = "txtDestinatario";
            this.txtDestinatario.Size = new System.Drawing.Size(159, 24);
            this.txtDestinatario.TabIndex = 2;
            this.txtDestinatario.Text = "Email Destinatario";
            // 
            // txtAssunto
            // 
            this.txtAssunto.AutoSize = true;
            this.txtAssunto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssunto.Location = new System.Drawing.Point(85, 87);
            this.txtAssunto.Name = "txtAssunto";
            this.txtAssunto.Size = new System.Drawing.Size(83, 24);
            this.txtAssunto.TabIndex = 4;
            this.txtAssunto.Text = "Assunto:";
            // 
            // tbAssunto
            // 
            this.tbAssunto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAssunto.Location = new System.Drawing.Point(174, 83);
            this.tbAssunto.Name = "tbAssunto";
            this.tbAssunto.Size = new System.Drawing.Size(291, 30);
            this.tbAssunto.TabIndex = 5;
            // 
            // tbConteudo
            // 
            this.tbConteudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbConteudo.Location = new System.Drawing.Point(184, 149);
            this.tbConteudo.Multiline = true;
            this.tbConteudo.Name = "tbConteudo";
            this.tbConteudo.Size = new System.Drawing.Size(388, 200);
            this.tbConteudo.TabIndex = 6;
            // 
            // txtCorpoEmail
            // 
            this.txtCorpoEmail.AutoSize = true;
            this.txtCorpoEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorpoEmail.Location = new System.Drawing.Point(25, 156);
            this.txtCorpoEmail.Name = "txtCorpoEmail";
            this.txtCorpoEmail.Size = new System.Drawing.Size(153, 20);
            this.txtCorpoEmail.TabIndex = 7;
            this.txtCorpoEmail.Text = "Conteúdo do E-mail:";
            // 
            // btEnviar
            // 
            this.btEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btEnviar.Location = new System.Drawing.Point(29, 241);
            this.btEnviar.Name = "btEnviar";
            this.btEnviar.Size = new System.Drawing.Size(122, 39);
            this.btEnviar.TabIndex = 8;
            this.btEnviar.Text = "Enviar";
            this.btEnviar.UseVisualStyleBackColor = true;
            this.btEnviar.Click += new System.EventHandler(this.btEnviar_Click);
            // 
            // frmEmail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 361);
            this.Controls.Add(this.btEnviar);
            this.Controls.Add(this.txtCorpoEmail);
            this.Controls.Add(this.tbConteudo);
            this.Controls.Add(this.tbAssunto);
            this.Controls.Add(this.txtAssunto);
            this.Controls.Add(this.tbDestinatario);
            this.Controls.Add(this.txtDestinatario);
            this.Controls.Add(this.tbRemetente);
            this.Controls.Add(this.txtEmailRemetente);
            this.Name = "frmEmail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmEmail";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtEmailRemetente;
        private System.Windows.Forms.TextBox tbRemetente;
        private System.Windows.Forms.TextBox tbDestinatario;
        private System.Windows.Forms.Label txtDestinatario;
        private System.Windows.Forms.Label txtAssunto;
        private System.Windows.Forms.TextBox tbAssunto;
        private System.Windows.Forms.TextBox tbConteudo;
        private System.Windows.Forms.Label txtCorpoEmail;
        private System.Windows.Forms.Button btEnviar;
    }
}